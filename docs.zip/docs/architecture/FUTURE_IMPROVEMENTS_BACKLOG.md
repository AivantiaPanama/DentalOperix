# Future Improvements Backlog

## Purpose

This backlog records non-critical future improvements discovered during certified DentalOperix programs.

Items listed here are not active implementation approvals, not production blockers, and not architecture changes. They are tracked to avoid losing useful observations while preserving the certified baselines.

## Governance Baseline

This backlog is governed by:

- `docs/architecture/57.9_DOCUMENTATION_CONSOLIDATION_AND_PROGRAM_CLOSURE.md`
- `docs/architecture/58.0_REVENUE_INTELLIGENCE_PROGRAM_PLAN.md`
- `docs/architecture/59.4_EXECUTIVE_ANALYTICS_CLOSURE_AND_CERTIFICATION.md`
- `docs/architecture/60.0_CLINICAL_INTELLIGENCE_PROGRAM_PLAN.md`

Certified source of truth remains unchanged:

```text
Leads = Source of Truth
```

Certified persistence architecture remains unchanged:

```text
Leads
  -> LeadPersistencePort
  -> LeadPersistenceProvider
  -> RelationalLeadPersistenceAdapter
  -> Supabase PostgreSQL
```

## Backlog Policy

A backlog item must remain classified as a future improvement unless it receives explicit approval through the standard DentalOperix governance process:

1. Architectural analysis
2. Affected dependencies
3. Risks
4. Technical impact
5. Implementation plan
6. Explicit approval before code generation

## Current Items

### FI-001 - TanStack Router Route Export Optimization

Status: OPEN  
Priority: LOW  
Category: Technical Optimization  
Risk: LOW  
Impact: Bundle size / code splitting

Runtime development logs reported that `DashboardPage` is exported from:

```text
src/routes/admin/dashboard.tsx
```

TanStack Router warns that this prevents optimal code splitting for that export.

Recommended future action:

```text
Move DashboardPage into a non-route component module and keep the route file focused on Route registration.
```

Constraints:

- must not modify protected components
- must preserve dashboard behavior
- must include dashboard route tests

### FI-002 - Revenue Dashboard Fallback Telemetry

Status: OPEN  
Priority: MEDIUM  
Category: Observability  
Risk: LOW  
Impact: Operational visibility

60.2-HF1 added a controlled fallback from Revenue Intelligence to CRM metrics when `/api/analytics/revenue` is unavailable.

Recommended future action:

```text
Add lightweight telemetry or structured logging when the fallback path is used.
```

Purpose:

- detect recurring Revenue Intelligence failures
- quantify fallback frequency
- support operational diagnostics

Constraints:

- no persistence writes unless separately approved
- no new source of truth
- no dashboard blocking behavior

### FI-003 - Executive Alert Prioritization

Status: OPEN  
Priority: LOW  
Category: Executive Analytics  
Risk: LOW  
Impact: Decision support quality

Executive Analytics currently surfaces alerts and priority actions. A future refinement can sort and group alerts by estimated impact, urgency, and executive relevance.

Recommended future action:

```text
Rank executive alerts by severity, KPI impact, and recommended action priority.
```

Constraints:

- must remain derived/read-only analytics
- must not introduce automation execution
- must not modify lead, patient, or appointment data

### FI-004 - Clinical Data Completeness Dashboard

Status: PLANNED  
Priority: MEDIUM  
Category: Clinical Intelligence  
Risk: MEDIUM  
Impact: Clinical analytics quality

60.2 introduced `ClinicalIntelligenceSnapshot` and clinical quality metrics. A future dashboard can expose completeness signals for clinical read-model coverage.

Recommended future action:

```text
Create a clinical data quality panel showing treatment plans, stages, outcomes, and patient coverage gaps.
```

Constraints:

- clinical analytics must remain read-only
- no clinical writes
- no patient master-data replacement
- no treatment plan mutation

### FI-005 - Favicon Development Asset

Status: OPEN  
Priority: LOW  
Category: Developer Experience  
Risk: LOW  
Impact: Console cleanliness

Development logs may show:

```text
GET /favicon.ico 404
```

Recommended future action:

```text
Add or confirm a public favicon asset if desired.
```

This is non-functional and should not block any certified program.

## Protected Components

Future improvements must not modify the protected components unless formally approved through executive governance:

```text
BookingDialog
processDentalLead
/api/leads/create
Calendar
Gmail
FloatingDentalAIChat
Home
siteServices.ts
```

## Current Backlog Summary

```text
FI-001  TanStack Router Route Export Optimization       OPEN      LOW
FI-002  Revenue Dashboard Fallback Telemetry            OPEN      MEDIUM
FI-003  Executive Alert Prioritization                  OPEN      LOW
FI-004  Clinical Data Completeness Dashboard            PLANNED   MEDIUM
FI-005  Favicon Development Asset                       OPEN      LOW
```


## FI-007 Dashboard Period State Alignment

Priority: MEDIUM

Status: OPEN

Category: Admin Dashboard UX

Description:

Investigate and normalize the admin dashboard period-selection state so that the highlighted button, displayed period label, URL hash, Revenue Intelligence request period, and Executive Analytics request period always represent the same value.

Rationale:

Manual testing showed confusing behavior where selecting a control appeared to produce unexpected UI state. This is separate from the analytics endpoint resilience hotfix and should be addressed as a focused UI-state alignment task.

Restrictions:

- Do not modify protected components.
- Do not change persistence.
- Do not change Leads source-of-truth governance.

### FI-007 - Dashboard Filter State Synchronization

Status: OPEN  
Priority: MEDIUM  
Category: UI State / Dashboard Consistency  
Risk: LOW  
Impact: Admin dashboard filter accuracy

Observed behavior:

```text
The visual active period chip can differ from the effective period shown by the dashboard.
```

Example symptom:

```text
Visual button: Hoy
Effective period label: Todo
```

Recommended future action:

```text
Open a separate dashboard filter synchronization hotfix after Assistant fallback cleanup validation.
```

Governance note:

This item is not part of 60.2-HF5. It must be handled as a separate approved change because it affects UI state behavior, not endpoint resilience.


## FI-008 Assistant Fallback State Cleanup

Priority: MEDIUM

Status: RESOLVED IN 60.2-HF6

Category: Assistant UI State

Description:

Manual testing confirmed that `/api/leads/list` returned real Google Sheets data without `fallback: true`, while the Assistant UI could still display the demo-data banner.

Resolution:

Implemented `60.2-HF6 Assistant Fallback State Cleanup` to clear stale fallback state during refresh and only show the demo banner when the API explicitly returns `fallback: true`.

Governance note:

No persistence, Google Sheets write path, lead ingestion, or protected components were modified.

## FI-009 Data Quality Encoding Audit

Priority: HIGH  
Status: RESOLVED IN 60.3  
Category: Data Quality / Analytics Consistency

Description:

Manual validation identified mojibake values such as `OdontologÃa`, `DiseÃ±o`, and `RevisiÃ³n` in CRM-derived reads.

Resolution:

Implemented 60.3 Data Quality and Encoding Audit with conservative read-side normalization and CRM metrics service grouping normalization.

Governance note:

No persistence, source-of-truth, Google Sheets write path, lead creation path, or protected component was modified.

## Resolved During 60.3-HF1

### FI-ENC-001 Incomplete Mojibake Pattern Expansion

Status: RESOLVED

Expanded conservative read-side normalization for observed incomplete mojibake values such as `OdontologÃa` and `MartÃnes`. No persistence writes were introduced.


## Resolved During 60.3-HF2

### FI-DASH-001 Dashboard Empty State Guard

Status: RESOLVED

Manual testing confirmed that `/api/analytics/revenue?period=all` could return real Google Sheets data with `snapshot.totals.leads > 0` while the Admin Dashboard still showed the empty CRM message on first navigation.

Resolution: 60.3-HF2 introduced a guarded empty-state condition based on both `emptyCRM` and `totals.leads === 0`, preventing stale or transitional empty-state display when real leads are present.

Governance note: no persistence, source-of-truth, Google Sheets write path, lead creation path, or protected component was modified.

## FI-009 Dashboard First Load Monitoring

Status: OPEN  
Priority: LOW  
Category: Observability

After 60.3-HF3, the dashboard reconciles transient first-load empty snapshots. A future improvement may add lightweight telemetry to count reconciliation events and identify if external data sources are intermittently slow.

Governance:

```text
Persistence Change Required: NO
Source of Truth Change Required: NO
```

## Resolved During 60.3-HF4

### FI-GOV-001 Development Governance Patterns Consolidation

Status: RESOLVED

Manual stabilization work across 60.2-HF4 through 60.3-HF3 showed that future implementations need a reusable governance and runtime-pattern baseline before code generation.

Resolution:

```text
docs/architecture/DEVELOPMENT_GOVERNANCE_PATTERNS.md
docs/architecture/IMPLEMENTATION_CHECKLIST.md
docs/architecture/60.3-HF4_DEVELOPMENT_GOVERNANCE_PATTERNS_CONSOLIDATION.md
```

The new baseline captures:

```text
Endpoint Resilience Pattern
Fallback Guard Pattern
Dashboard First Load Reconciliation Pattern
Google Sheets Diagnostic Pattern
Encoding Normalization Pattern
Session Validation Pattern
Read-Only Analytics Pattern
Documentation-Before-Code Pattern
Test and Manual Validation Pattern
```

Governance note:

```text
Persistence Change: NO
Source of Truth Change: NO
Protected Components Modified: NO
Functional Code Change: NO
```

## Current Governance Reference

Future backlog items and new implementation proposals should start by reviewing:

```text
docs/architecture/DEVELOPMENT_GOVERNANCE_PATTERNS.md
docs/architecture/IMPLEMENTATION_CHECKLIST.md
```

This is now the reusable development baseline for avoiding repeated investigation of already certified patterns.


### FI-004 - Runtime Persistence Observability

Status: OPEN  
Priority: MEDIUM  
Category: Observability / Governance  
Risk: LOW  
Impact: Operational traceability

60.4 aligned runtime lead access to the certified persistence provider and restricted Google Sheets to rollback mode. A future improvement can add structured telemetry for active persistence mode, rollback activation, and fail-closed relational configuration errors.

Constraints:

- no analytics writes
- no dual write
- no new source of truth
- no logging of secrets or patient-sensitive payloads


## Resolved During 60.4-HF1

### FI-BOOKING-001 Booking Confirmation Silent Submit

Status: RESOLVED  
Priority: HIGH  
Category: Conversion / UX Reliability

A user reported that the public booking dialog did not visibly react after clicking **Confirmar reserva** with date and time selected.

Resolution:

```text
src/components/site/BookingDialog.tsx
src/components/site/BookingDialog.test.tsx
docs/architecture/60.4-HF1_BOOKING_CONFIRMATION_ACTION_GUARD.md
```

Implemented visible submitting feedback, duplicate submit guard, validation error visibility, and focused UI tests.

Governance note:

```text
Persistence Change: NO
Source of Truth Change: NO
Protected Component Modified: YES - BookingDialog, explicitly approved
```

### FI-BOOKING-002 Booking Submission Observability

Status: OPEN  
Priority: MEDIUM  
Category: Observability / Conversion

Future improvement: route `booking_submit_clicked`, `booking_submit_started`, and `booking_submit_failed` into approved observability without writing analytics data into the Leads source of truth and without logging patient-sensitive payloads.

Constraints:

```text
No analytics writes to source-of-truth tables
No patient-sensitive payload logging
No bypass of RBAC
```

### FI-004 - External Email Deliverability Monitoring

Status: OPEN  
Priority: MEDIUM  
Category: Observability / Notifications  
Risk: LOW  
Impact: Operational visibility

60.4-HF2 sends patient and clinic booking emails separately and exposes delivery state. A future improvement can add structured delivery telemetry or an operational dashboard to detect recurring external email delivery failures.

Recommended future action:

```text
Track patient and clinic notification delivery outcomes in operational logs or a derived read-only monitoring view.
```

Constraints:

- no new source of truth
- no analytics write path to Leads
- no blocking of primary lead persistence
- no storage of secrets or email bodies in telemetry

### FI-005 - ICS Attachment for Non-Google Patients

Status: OPEN  
Priority: MEDIUM  
Category: Patient Experience  
Risk: LOW  
Impact: Calendar compatibility

60.4-HF2 invites patient emails through Google Calendar and sends a confirmation email through Gmail. A future enhancement can attach a standard `.ics` calendar file to the patient confirmation email for recipients whose email provider does not automatically recognize Google Calendar invitations.

Recommended future action:

```text
Generate and attach a standards-compliant ICS invite to patient booking confirmations.
```

Constraints:

- Gmail remains a notification channel only
- no persistence re-architecture
- no new source of truth
- preserve fail-soft behavior for notification errors

### FI-006 - Dedicated Clinic Notification Mailbox

Status: OPEN  
Priority: MEDIUM  
Category: Notifications / Operations  
Risk: LOW  
Impact: Clinic delivery reliability

60.4-HF3 improves visibility for clinic self-notifications when `CLINIC_NOTIFICATION_EMAIL` equals `GMAIL_SENDER`. A future operational improvement is to use a dedicated clinic notification mailbox or Google Group that is different from the sender account.

Recommended future action:

```text
Set CLINIC_NOTIFICATION_EMAIL to a monitored clinic inbox or group distinct from GMAIL_SENDER.
Keep GMAIL_SENDER as the authenticated sender/alias.
Validate inbox delivery with patient email different from clinic email.
```

Constraints:

- Gmail remains a downstream notification channel only
- no new source of truth
- no storage of email bodies in analytics
- no rollback of lead persistence due to notification visibility issues

## Future Improvement: Rich ICS RSVP Semantics

60.4-HF4 attaches `invite.ics` to the unified patient confirmation email using a portable publish-style calendar attachment. A future improvement may evaluate full RSVP semantics (`METHOD:REQUEST`, organizer/attendee metadata, and provider-specific deliverability behavior) if the clinic wants formal accept/decline tracking from patient calendars. This must remain downstream of Leads as Source of Truth.

### FI-061 - Product Governance and AI Delivery Framework

Status: ACTIVE  
Priority: HIGH  
Category: Product Governance / AI Delivery  
Risk: LOW  
Impact: Delivery acceleration and continuity

DentalOperix now tracks 61.x as the product governance and AI-assisted delivery program.

New documented initiatives:

- `61.1 Users & RBAC Foundation`
- `61.2 Assistant Operations Dashboard`
- `61.3 Patient Management`
- `61.4 Admin Starter Dashboard UX Redesign`
- `61.5 Appointment Lifecycle Analytics`

Primary references:

- `docs/product-governance/61.0_MASTER_PRODUCT_ROADMAP.md`
- `docs/ai-governance/61.0_AI_WORKFLOW_CONTROL_CENTER.md`
- `docs/ai-governance/61.0_AI_TASK_BOARD.md`

No implementation is approved by this backlog entry alone. Each initiative still requires the standard DentalOperix proposal and explicit approval process.
